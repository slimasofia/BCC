<?php

$amountIncomes = "<script>document.write(amountIncomes)</script>"; //varJs é a variavel que você nomeou no JS.
// passar esse dado para o banco depois
echo($amountIncomes);

 ?>