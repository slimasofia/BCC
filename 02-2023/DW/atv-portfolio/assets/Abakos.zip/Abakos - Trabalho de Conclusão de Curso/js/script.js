const tbody = document.querySelector("tbody");
const descItem = document.querySelector("#desc");
const amount = document.querySelector("#amount");
const type = document.querySelector("#type");
const btnNew = document.querySelector("#btnNew");
const incomes = document.querySelector(".incomes");
const expenses = document.querySelector(".expenses");
const total = document.querySelector(".total");

let items;

btnNew.onclick = () => {
    if (descItem.value === "" || amount.value === "" || date.value === "" || type.value === "") {
        return alert("Preencha todos os campos!");
    }

    items.push({
        desc: descItem.value,
        amount: Math.abs(amount.value).toFixed(2),
        date: date.value,
        type: type.value,
    });

    setItensBD();
    loadItens();

    descItem.value = "";
    amount.value = "";
};

function deleteItem(index) {

    items.splice(index, 1);
    setItensBD();
    loadItens();
}

function insertItem(item, index) {
    let tr = document.createElement("tr");

    tr.innerHTML = `
    <td id="itemDesc">${item.desc}</td>
    <td>R$ ${item.amount}</td>
    <td>${item.date}</td>
    <td class="columnType">${item.type === "Entrada"
            ? '<i class="bx bxs-chevron-up-circle"></i>'
            : '<i class="bx bxs-chevron-down-circle"></i>'
        }</td>
    <td class="columnAction">
      <button onclick="deleteItem(${index})"><i class='bx bx-trash'></i></button>
    </td>
  `;

    tbody.appendChild(tr);
}

function loadItens() {
    items = getItensBD();
    tbody.innerHTML = "";
    items.forEach((item, index) => {
        insertItem(item, index);
    });

    getTotals();
}

function getTotals() {
    const amountIncomes = items
        .filter((item) => item.type === "Entrada")
        .map((transaction) => Number(transaction.amount));

    const amountExpenses = items
        .filter((item) => item.type === "Saída")
        .map((transaction) => Number(transaction.amount));

    const totalIncomes = amountIncomes
        .reduce((acc, cur) => acc + cur, 0)
        .toFixed(2);

    const totalExpenses = Math.abs(
        amountExpenses.reduce((acc, cur) => acc + cur, 0)
    ).toFixed(2);

    const totalItems = (totalIncomes - totalExpenses).toFixed(2);

    incomes.innerHTML = `R$ ${totalIncomes}`;
    expenses.innerHTML = `R$ ${totalExpenses}`;
    total.innerHTML = `R$ ${totalItems}`;
    //console.log(amountIncomes);
}

const getItensBD = () => JSON.parse(localStorage.getItem("db_items")) ?? [];
const setItensBD = () =>
    localStorage.setItem("db_items", JSON.stringify(items));

loadItens();










// Gráficos
const amountIncomes = items
    .filter((item) => item.type === "Entrada")
    .map((transaction) => Number(transaction.amount));

const amountExpenses = items
    .filter((item) => item.type === "Saída")
    .map((transaction) => Number(transaction.amount));

const totalIncomes = amountIncomes
    .reduce((acc, cur) => acc + cur, 0)
    .toFixed(2);

const totalExpenses = Math.abs(
    amountExpenses.reduce((acc, cur) => acc + cur, 0)
).toFixed(2);

const totalItems = (totalIncomes - totalExpenses).toFixed(2);

incomes.innerHTML = `R$ ${totalIncomes}`;
expenses.innerHTML = `R$ ${totalExpenses}`;
total.innerHTML = `R$ ${totalItems}`;


const labels = [
    'Entradas',
    'Saídas',

];

//const receita = localStorage.getItem("db_items"); //objeto
//console.log(receita);

//const t = amount.value;
// console.log(t)

const data = {
    labels: labels,
    datasets: [{
        backgroundColor: ['rgb(46, 204, 113)',
            'rgb(192, 57, 43)'],
        borderColor: ['rgb(46, 204, 113)',
            'rgb(192, 57, 43)'],
        data: [amountIncomes, amountExpenses],
    }]
};

const config = {
    type: 'doughnut',
    data: data,
    options: {}
};

function mostrarGrafico() { }



const myChart = new Chart(
    document.getElementById('myChart'),
    config
);




function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}