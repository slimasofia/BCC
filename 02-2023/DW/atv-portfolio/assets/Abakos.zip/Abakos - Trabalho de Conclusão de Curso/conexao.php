<?php
$localhost = "localhost";
$user = "root";
$passwr = "";
$banco = "teste";

$conexao = mysqli_connect($localhost, $user, $passwr, $banco);

?>