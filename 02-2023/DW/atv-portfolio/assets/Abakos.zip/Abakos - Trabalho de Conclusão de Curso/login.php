<!doctype html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/cad.css">
    <title>Entrar</title>
</head>

<body>
    <div class="form-group col-10 col-md-6 col-lg-6">

        <div class="row justify-content-center mb-4">
            <img src="assets/abakos.png" class="img-fluid">
        </div>

        <form action="verifica_login.php" method="POST">

            <div class="input-box">
                <label for="email">E-mail:</label>
                <input id="email" type="email" name="email" placeholder="Digite seu e-mail" required>
            </div>

            <div class="input-box">
                <label for="password">Senha:</label>
                <input id="password" type="password" name="senha" placeholder="Digite sua senha" required>
            </div>

            <div class="submit-button">
                <button type="submit" name="submit" class="btn btn-primary">Entrar</button>
            </div>
        </form>
    </div>

</body>

</html>