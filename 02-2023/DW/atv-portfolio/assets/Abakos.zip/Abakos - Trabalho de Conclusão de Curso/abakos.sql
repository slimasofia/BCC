create database abakos;
use abakos;

create table usuarios(
id int auto_increment primary key,
nome varchar(100) not null,
email varchar(100) not null,
senha varchar(12) not null
);

CREATE TABLE events (
  `id` int auto_increment primary key,
  `title` varchar(90) NOT NULL,
  `description` varchar(120) NOT NULL,
  `color` varchar(10) NOT NULL,
  `start` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `end` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
