<?php
include("conexao.php");

$nome = $_POST['nome'];
$email = $_POST['email'];
$senha = $_POST['senha'];
$sql = "INSERT INTO usuarios (nome, email, senha) VALUES ('$nome', '$email', '$senha')";
$result = mysqli_query($conexao, $sql);

if(!$result) {
    echo("ocorreu um erro");
} else {
?>
<script>
    alert("Cadastro realizado com sucesso.");
    location.href = "login.php";
</script>
<?php
}
?>